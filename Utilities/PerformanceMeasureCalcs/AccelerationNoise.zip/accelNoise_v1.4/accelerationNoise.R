# Summary -----------------------------------------------------------------
# Title: Link acceleration noise estimation based on SwashSim outputs
# Codename: Libertango
# Version: 1.4
# Authors:
#   - Anna 
#   - Leonida 
#   - Luan G. S. Carvalho (lstaichakcarvalh@ufl.edu)
#   - Tia Lubbers (tlubbers@ufl.edu)
# Overview:
#   This script gathers all time-step simulation files from a folder and
#   estimates two acceleration noise values for each link: (i) with mean=0
#   and (ii) with the actual mean observed for the acceleration on the link.
#   
#   The procedure is performed by first filtering out invalid vehicles from
#   the data set, and then simply computing the acceleration noise 
#   functions exposed in the Wiki website.
#   
#   Two outputs are created: (i) a spreadsheet summarizing the estimated 
#   acceleration noise measurements for each link, and (i) the individual 
#   link time step data outputted as csv files for conference with other 
#   tools.

# Instructions:
#   - Put this script in the upper folder where the csv files are stored
#   - This script should run with R versions 3.4 or newer
#   - This script is ready to be used with the Section features of RStudio.
#     You can easily run the section where your cursor currently is by 
#     pressing Ctrl+Alt+T

# Inputs ------------------------------------------------------------------

#Folder setup
timeStepCsvFolder = "inputs/timeStepData" # add the simulation time-step
#                                           .csv output data here
linkResultsFolder = "inputs/linkResultsData" #  add the link results
#                                               .csv output data here

individualLinkTimeStepFolder = "outputs/individualLinksTimeStep"
accelNoiseOutputFolder = "outputs/accelerationNoiseSheet"

# Choose whether to use a custom list of links or to use all links present 
# in the time-step output from SwashSim
useCustomLinkList = 'No'
customLinkList = c(23,32)

# The following should match the configuration in SwashSim.
warmUp= 300 #seconds. 
simDuration = 1800 #seconds

# Preparing the R environment ---------------------------------------------

usePackage <- function(p) 
{
# This function checks if a library is installed. 
# If not, then the library is automatically installed 
  if (!is.element(p, installed.packages()[,1]))
    install.packages(p, dep = TRUE)
  require(p, character.only = TRUE)
}

usePackage("rstudioapi") #  required for custom function set_wd
usePackage("collections") # required for using dictionaries

# The following two libraries will only work with R 3.6.1 and above (needs to 
# change some variable names to make it work). They run faster than the 
# current method, though.
#usePackage("plyr") 
#usePackage("readr")

set_wd <- function() {  # changes the working directory to 
#                         wherever this R script is located.
  current_path <- getActiveDocumentContext()$path 
  setwd(dirname(current_path ))
  print( getwd() )
}

set_wd() # no more absolute paths!

# Importing the time-step data --------------------------------------------

cat("procedure started at",format(Sys.time(), "%a %b %d %X %Y"))

filesInFolder = list.files(path=timeStepCsvFolder, 
                           pattern="*.csv",full.names=TRUE)

#combinedCsv = ldply(filesInFolder,read_csv) # creates a single dataframe 
# # with all csv files. It may take a couple seconds.
# # This function might cause issues depending on your R version. Use it
# # with the plyr and readr packages commented in the previous section.

combinedCsv <- do.call( # creates a single dataframe with all csv 
#                         files in the folder. This might take a while to 
#                         complete. 
                        rbind,
                        lapply(filesInFolder,read.csv))

cat("Completed data importing at",format(Sys.time(), "%a %b %d %X %Y"))

# Defining the list of links to be analyzed -------------------------------

# Identifying all links with vehicle data
linkList = unique(combinedCsv$Link.ID, incomparables = FALSE)

# Reading the link results SwashSim output
linkResults = read.csv(paste(linkResultsFolder,"/LinkResults.csv",sep=""))
# Dropping entry and exit links

linksOnly<-linkResults[!(
  linkResults$Link.Type=="Two-Lane Highway Exit" | (
    linkResults$Link.Type=="Two-Lane Highway Entry")),]


#define the studyLinkList variable (custom list or "all links")
if (useCustomLinkList == 'Yes') {
  cat("Estimating acceleration noise for custom list of links \n")

  studyLinkList = customLinkList
  cat("Custom list:",customLinkList)
  
} else {

    studyLinkList = c(linksOnly$Link.Id)
    cat("Using full links list (except entry and exit links):",studyLinkList)
}

# Preparing the dictionaries of spreadsheets for each link ----------------

# In order to eliminate invalid vehicles, it is necessary to compare the 
# local (link) recorded simulation data with the warmup data and the global
# (all links) data.

fullLinkTimeStep <- Dict() #  because dictionaries are the best data 
#                             structure in the world
noWarmUpLinkTimeStep <- Dict() # it has already been completely justified

# Building the dictionaries of time-step data per link --------------------

cat("Building dictionaries of individual link dataframes \n")
for(link in studyLinkList){

  cat("iterating for link",link,
      "started at",format(Sys.time(), "%a %b %d %X %Y"),"\n")
  
  filteredDf = combinedCsv
  filteredDf$Link.ID <- lapply(filteredDf$Link.ID, 
                               as.character) #  changing the column data 
#                                               type to string
                       
  filteredDf <- filteredDf[grep(paste("^",link,sep=""),
                                filteredDf$Link.ID),] # filtering to use 
#                               only the current link
  filteredDf$Link.ID = unlist(filteredDf$Link.ID) # required to prevent 
#                       bugs when saving the table to a .csv file

# Saving the raw time-step data per link    
  write.csv(filteredDf,
            file = paste(individualLinkTimeStepFolder,"/",
                         "linkTimeStep_",
                         link,
                         ".csv",sep=""))
  
# Adding the filtered time-step link data to the dictionary. Entries have
# to be called as strings. R takes its definitions quite seriously.
  fullLinkTimeStep$set(as.character(link),filteredDf)
  
# Filtering out the warmup period and adding the dataframe to another dict.
  noWarmupDf <- filteredDf[filteredDf$SimTime >warmUp,]
  noWarmUpLinkTimeStep$set(as.character(link),noWarmupDf)
  
}  

# Initializing the output table with empty values -------------------------

df <- data.frame(matrix(ncol = 3, nrow = 0))
x <- c("Link.ID", "AccelNoiseMean0", "AccelNoiseVarMean")
colnames(df) <- x

rowID = 1 # We will iterate the rows after the acceleration noise is
#           estimated for that link



# Eliminating invalid vehicles and estimating acceleration noise ----------

cat("Estimating Acceleration noise for each link \n")
for(link in studyLinkList){
  
  cat("iterating for link",link,
      "started at",format(Sys.time(), "%a %b %d %X %Y"),"\n")
  
  
# Defining the current link main simulation (no warmup) table
  mainSimDf <- noWarmUpLinkTimeStep$get(as.character(link))

# Defining the current link table with all time-step (with warmup)
  fullSimDf <- fullLinkTimeStep$get(as.character(link))
  
# Obtaining the initial vehicle list
  vehList = unique(mainSimDf$Veh.Index, incomparables = FALSE)
  
# Creating an empty list of valid vehicles
  validVehList = c()
  
  for(vehicle in vehList) {
    
# Getting the observations for the current vehicle in:
# - the main simulation (no warmup) table for the current link
    subDfSim <- mainSimDf[mainSimDf$Veh.Index ==vehicle,]
# - the whole link table (with warmup)     
    subDfWarmUp <- fullSimDf[fullSimDf$Veh.Index ==vehicle,]
# - the whole dataframe (all links included)    
    allLinksDf <- combinedCsv[combinedCsv$Veh.Index ==vehicle,]
    
# Preparing to filter out vehicles that began to traverse the link during
# the warmup period:
# - Finding the initial time-step for the vehicle on this link in
#   - the main simulation period (no warmup)
    simStart = min(subDfSim$SimTime)
#   - the full simulation period (with warmup)
    realStart = min(subDfWarmUp$SimTime)
    
# Preparing to filter out vehicles that did not complete to traverse the 
# link
# - Finding the final time-step for the vehicle on this link     
    simEnd = max(subDfSim$SimTime)
# - Finding the final time-step for the vehicle in ALL links    
    realEnd = max(allLinksDf$SimTime)
    
# Filtering invalid vehicles:
# If the vehicle either:
#   - started to traverse the link during warmup, or
#   - there is no evidence that the vehicle entered another link before
#     the end of the simulation,
# then the vehicle is not accounted when estimating acceleration noise 
# for this link
    
    if (simStart  == realStart && simEnd< realEnd) {
      #cat("Valid vehicle",vehicle, "\n")
      
      validVehList <- c(validVehList, vehicle)
      
    } #else {
#      #cat("Invalid vehicle",vehicle, "\n")
#    }
# Notice that invalid vehicles are simply ignored.
    
  } # Finished vehicle iterations for this link
  
  
  
  filteredDf = mainSimDf # ...this is just a lazy movement.

  
  
  
# Preparing the elements in the acceleration noise equation (mean 0).
  
# - Preparing an empty vector to gather the motion time for each vehicle
  MotionTime = vector()
  
  for(vehicle in validVehList) {
    
    subDf <- filteredDf[filteredDf$Veh.Index ==vehicle,]
    
#   - The vehicle time-in-motion is the total of time-steps observed
    deltaTime = nrow(subDf)
    MotionTime <- append(MotionTime,deltaTime,after=length(MotionTime))
    
  }

#   - The total time-in-motion is the sum of the MotionTime vector  
  travelTimeInMotion = sum(MotionTime)
  
  
# - Estimating the squared accelerations 
  filteredDf$SquaredAccel = filteredDf$Accel^2
# - Summing the squared accelerations
  summedSqAccel = sum(filteredDf$SquaredAccel)
# - Estimating the acceleration noise for mean equal to 0
  accelNoiseMean0 = (summedSqAccel/travelTimeInMotion)^(1/2)


# Preparing for the acceleration noise equation (non-zero mean). 
  # Estimating the average acceleration
  avgAccel = mean(filteredDf$Accel)
  # Estimating the squared difference between acceleration and avg. accel.
  filteredDf$SqAccelMinusMean = (filteredDf$Accel-avgAccel)^2
  # Summing the squared difference
  summedSqAccelVarMean = sum(filteredDf$SqAccelMinusMean)
  # - Estimating the acceleration noise for non-zero mean 
  accelNoiseVarMean = (summedSqAccelVarMean/travelTimeInMotion)^(1/2)
  
  # Saving the results to the rows of a final spreadsheet
  df[rowID,"Link.ID"] <- link
  df[rowID,"AccelNoiseMean0"] <- accelNoiseMean0
  df[rowID,"AccelNoiseVarMean"] <- accelNoiseVarMean

  rowID = rowID+1 #adding another row to the spreadsheet
}


# Comparing R and SwashSim results ----------------------------------------

#df = read.csv(paste(accelNoiseOutputFolder,"/AccelNoisePerLink.csv",sep=""))

comparisonDf <- merge(df,
                      linksOnly[,
                                  c("Link.Id",
                                    "Accel.Noise.Mean.Zero..ft.s2.",
                                    "Accel.Noise.Mean.NonZero..ft.s2.")],
                      by.x = "Link.ID",by.y="Link.Id")

names(comparisonDf) <- c("Link", 
                         "R_AccelNoiseMean0","R_AccelNoiseMeanNon0",
                         "Sim_AccelNoiseMean0","Sim_AccelNoiseMeanNon0")
comparisonDf$DiffMean0 <- (
  comparisonDf$R_AccelNoiseMean0 - comparisonDf$Sim_AccelNoiseMean0)
comparisonDf$DiffMeanNon0 <- (
  comparisonDf$R_AccelNoiseMeanNon0 - comparisonDf$Sim_AccelNoiseMeanNon0)

# Saving the final results to a .csv file
write.csv(comparisonDf,
            file = paste(accelNoiseOutputFolder,
                       "/AccelNoisePerLink.csv",sep=""))


cat("procedure finished at",format(Sys.time(), "%a %b %d %X %Y"))
